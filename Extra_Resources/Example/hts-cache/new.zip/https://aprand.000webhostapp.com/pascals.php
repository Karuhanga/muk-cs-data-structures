<html>
	<head>
		<title>Welcome</title>
		<link rel="stylesheet" href="css/bootstrap.min.css">
		<link rel="stylesheet" href="css/main.css">
		<style> 
			.block {
            display: inline-block;
            position: relative;
            border: 1px solid grey;
            text-align: center;
            font-size: .8em;
            width: 2em;
			}
			
			.divblock {
            text-align: center;
            vertical-align: middle;
			}
			
			#pascal {
            margin: 0 auto;
            text-align: center;
			}
			
			.block:nth-child(odd) {
            background: grey;
			}
			
			.block:nth-child(even) {
            background: yellow ;
			}
		</style>
	</head>
	<body>
		
		<nav class="navbar navbar-inverse">
			<div class="container-fluid">
				<!-- Brand and toggle get grouped for better mobile display -->
				<div class="navbar-header">
					<button type="button" class="navbar-toggle collapsed" data-toggle="collapse"
                    data-target="#bs-example-navbar-collapse-1">
						<span class="sr-only">Toggle navigation</span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</button>
					<a class="navbar-brand" href="#">Data Structures and Algorithm</a>
				</div>
				
				<!-- Collect the nav links, forms, and other content for toggling -->
				<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
					<ul class="nav navbar-nav">
						<li class="active"><a href="index.html">Home <span class="sr-only">(current)</span></a></li>
						<li class="dropdown">
							<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">Basic data structures
							<span class="caret"></span></a>
							<ul class="dropdown-menu" role="menu">
								<li><a href="arrays.html">Arrays</a></li>
								<li><a href="queues.php">Queues</a></li>
								<li><a href="stacks.php">Stacks</a></li>
							</ul>
						</li>
						<li class="dropdown">
							<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">More data structures
							<span class="caret"></span></a>
							<ul class="dropdown-menu" role="menu">
								<li><a href="linkedlists.php">Linked Lists</a></li>
								<li><a href="priorityqueues.php">Priority Queue</a></li>
							</ul>
						</li>
						<li class="dropdown">
							<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">Sorting
							<span class="caret"></span></a>
							<ul class="dropdown-menu" role="menu">
								<li><a href="mergesort.php">Merge Sort</a></li>
								<li><a href="quickSort.php">Quick Sort</a></li>
								<li><a href="bubblesort.php">Buddle Sort</a></li>
								<li><a href="insertionSort.php">Insertion Sort</a></li>
								<li><a href="selectionSort.php">Selection Sort</a></li>
							</ul>
						</li>
						<li class="dropdown">
							<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">Searching
							<span class="caret"></span></a>
							<ul class="dropdown-menu" role="menu">
								<li><a href="binarySearch.php">Binary Search</a></li>
								<li><a href="linearSearch.php">Linear Search</a></li>
							</ul>
						</li>
						<li><a href="pascals.php">Pascals Triangle and Recursion</a></li>
					</ul>
				</div><!-- /.navbar-collapse -->
			</div><!-- /.container-fluid -->
		</nav>
		
		<div class="container">
			<div class="col-md-10 col-md-offset-1 card">
				<h2>Pascals Triangle and recursive functions</h2>
				<hr>
				<content>
					
					<div class="col-md-6">
						
						<p>Pascal’s triangle is a number triangle with numbers arranged in staggered rows such that</p>
						
						<img src="images/pascals_equation.jpg"/>
						
						<p>This equation is the equation for a binomial coeﬃcient. You can build Pascal’s triangle by adding the two numbers that are diagonally above a number in the triangle. Write a program that prints out Pascal’s triangle in O(n2). Provide an example for testing purposes</p>
						
						<b>Recursive Function</b>
						<p>Recursive program to calculate the sum of the positive integers of n + (n−2) + (n−4)...) Until n−x =< 0. </p>
							
							<form class="form-inline" method="POST" action="pascals.php">
								<div class="form-group">
									<input name="numb" type="text" class="form-control" id="exampleInputName2" placeholder="insert number">
								</div>
								<input class="btn btn-default" type="submit" name="get" value="GetSum"/>
							</form>
							
														
						</div>
						
						<div class="col-md-6">
							
							<b>Pascals Triangle</b>
							
							<p>Insert a number to display its pascals Triangle</p>
							<input class="form-control" type="text" placeholder="Enter number of rows for pascal Triangle" style="width:80%" id="numRows">
							<input class="btn btn-default" type="button" " value="Go " name="Go " onClick="printPascalTriangle() ">
							<div id="pascal"></div>
						
						
						
				</div>
				
			</content>
		</div>
		
	</div>
	
	<div class="footer">
		<p><b>&copy 2016</b> all rights reserved to group</p>
	</div>
	
	<script src="js/jquery.min.js" type="text/javascript"></script>
	<script src="js/bootstrap.min.js" type="text/javascript"></script>
	<script>
		function printPascalTriangle(){
			document.getElementById("pascal").innerHTML = "";
			var rows = document.getElementById("numRows").value;
			var arr = generatePascal(+rows);
			for(var i=0;i<arr.length;i++){
				var div = document.createElement('div');
				div.className ="divblock"
				for(var j=0;j<arr[i].length;j++){
					var span = document.createElement('span');
					span.innerHTML=arr[i][j];
					span.className ="block";
					div.appendChild(span);
				}
				document.getElementById("pascal").appendChild(div);
			}
		}
		function generatePascal(n){
			var arr = [];
			var tmp;
			for(var i=0;i<n;i++){
				arr[i]=[];
				for(var j=0; j<=i; j++){
					if(j==i){
						arr[i].push(1);
						}else{
						tmp = (!!arr[i-1][j-1]?arr[i-1][j-1]:0)+(!!arr[i-1][j]?arr[i-1][j]:0);
						arr[i].push(tmp);
					}
				}
			}
		return arr;
		}
		</script>
		<div style='text-align: right;position: fixed;z-index:9999999;bottom: 0; width: 100%;cursor: pointer;line-height: 0;'><a title="Hosted on free web hosting 000webhost.com. Host your own website for FREE." target="_blank" href="https://www.000webhost.com/?utm_source=000webhostapp&utm_campaign=000_logo&utm_medium=website_aprand&utm_content=footer_img"><img src="https://cloud.githubusercontent.com/assets/23024110/20663010/9968df22-b55e-11e6-941d-edbc894c2b78.png"  alt="www.000webhost.com"></a></div></body>
		</html>															