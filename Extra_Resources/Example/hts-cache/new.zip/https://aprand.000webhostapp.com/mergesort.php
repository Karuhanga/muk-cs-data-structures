
<html>
	<head>
		<title>Merge Sort</title>
		<link rel="stylesheet" href="css/bootstrap.min.css">
		<link rel="stylesheet" href="css/main.css">
	</head>
	<body>
		<nav class="navbar navbar-inverse">
			<div class="container-fluid">
				<!-- Brand and toggle get grouped for better mobile display -->
				<div class="navbar-header">
					<button type="button" class="navbar-toggle collapsed" data-toggle="collapse"
                    data-target="#bs-example-navbar-collapse-1">
						<span class="sr-only">Toggle navigation</span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</button>
					<a class="navbar-brand" href="#">Data Structures and Algorithm</a>
				</div>
				
				<!-- Collect the nav links, forms, and other content for toggling -->
				<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
					<ul class="nav navbar-nav">
						<li><a href="index.html">Home</a></li>
						<li class="dropdown">
							<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">Basic Data structures
							<span class="caret"></span></a>
							<ul class="dropdown-menu" role="menu">
								<li><a href="arrays.html">Arrays</a></li>
								<li><a href="queues.php">Queues</a></li>
								<li><a href="stacks.php">Stacks</a></li>
							</ul>
						</li>
						<li class="dropdown">
							<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">More data structures
							<span class="caret"></span></a>
							<ul class="dropdown-menu" role="menu">
								<li><a href="linkedlists.php">Linked Lists</a></li>
								<li><a href="priorityqueues.php">Priority Queue</a></li>
							</ul>
						</li>
						<li class="dropdown active">
							<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">Sorting
							<span class="caret"></span></a>
							<ul class="dropdown-menu" role="menu">
								<li><a href="mergesort.php">Merge Sort</a></li>
								<li><a href="quickSort.php">Quick Sort</a></li>
								<li><a href="bubblesort.php">Buddle Sort</a></li>
								<li><a href="insertionSort.php">Insertion Sort</a></li>
								<li><a href="selectionSort.php">Selection Sort</a></li>
							</ul>
						</li>
						<li class="dropdown">
							<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">Searching
							<span class="caret"></span></a>
							<ul class="dropdown-menu" role="menu">
								<li><a href="binarySearch.php">Binary Search</a></li>
								<li><a href="linearSearch.php">Linear Search</a></li>
							</ul>
						</li>
						<li><a href="pascals.php">Pascals Triangle and Recursion</a></li>
					</ul>
					
				</div><!-- /.navbar-collapse -->
			</div><!-- /.container-fluid -->
		</nav>
		
		<div class="container">
			<div class="col-md-10 col-md-offset-1 card">
				<h2>Merge Sort</h2>
				<hr>
				
				<div class="col-md-6">
				<p>Merge sort is a sorting technique based on divide and conquer technique. With worst-case time complexity being Ο(n log n), it is one of the most respected algorithms.</p>
				
				<p>Merge sort first divides the array into equal halves and then combines them in a sorted manner.</p>
				
				<br/>
				
				<b>Algorithm</b>
				
				<p>Merge sort keeps on dividing the list into equal halves until it can no more be divided. By definition, if it is only one element in the list, it is sorted. Then, merge sort combines the smaller sorted lists keeping the new list sorted too.</p>
				
				<pre class="result notranslate"><b>Step 1</b> − if it is only one element in the list it is already sorted, return. 
				<br/><b>Step 2</b> − divide the list recursively into two halves until it can no more be divided.
				<br /><b>Step 3</b> − merge the smaller lists into new list in sorted order.
				</pre>
				</div>
				
				<div class="col-md-6 leftShow">
				
				<form class="form-inline" method="GET" action="mergesort.php">
				<div class="form-group">
				<label for="exampleInputName2">Sample Students</label>
				<input name="sample" type="text" class="form-control" id="exampleInputName2" placeholder="insert sample number">
				</div>
				<button type="submit" class="btn btn-default">Start simulations</button>
				</form>
				
								
				</div>		
				
				</div>
				
				</div>
				
				<div class="footer">
				<p><b>&copy 2016</b> all rights reserved to group</p>
				</div>
				
				<script src="js/jquery.min.js" type="text/javascript"></script>
				<script src="js/bootstrap.min.js" type="text/javascript"></script>
				<div style='text-align: right;position: fixed;z-index:9999999;bottom: 0; width: 100%;cursor: pointer;line-height: 0;'><a title="Hosted on free web hosting 000webhost.com. Host your own website for FREE." target="_blank" href="https://www.000webhost.com/?utm_source=000webhostapp&utm_campaign=000_logo&utm_medium=website_aprand&utm_content=footer_img"><img src="https://cloud.githubusercontent.com/assets/23024110/20663010/9968df22-b55e-11e6-941d-edbc894c2b78.png"  alt="www.000webhost.com"></a></div></body>
				</html>											